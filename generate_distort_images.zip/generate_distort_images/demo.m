%setup
clear; clc;
addpath(genpath('code_imdistort'));


%Distort image based type and distortion level

ref_im = imread('Lenna.png');

[dist_im] = imdist_generator(ref_im, 1, 5);

imshow(dist_im);