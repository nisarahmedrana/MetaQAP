function n = ncols(x)
n = size(x,2);