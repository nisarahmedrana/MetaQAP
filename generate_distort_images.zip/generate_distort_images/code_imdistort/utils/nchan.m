function n = nchan(x)
n = nchans(x);