function b = imblurgauss(a, radius)

b = imgaussfilt(a, radius);